import java.util.Scanner;

public class Game_Setup extends Back_ground {
    boolean O_turn = true;
    boolean I_turn = false;
    int finisher_counter = 0;

    public void whose_turn(){
        //System.out.println("it's O turn");
        if (O_turn) {
            System.out.println("please enter coordinate (first row and then column)");
            Scanner sc = new Scanner(System.in);
            int row = sc.nextInt();
            int column = sc.nextInt();
            background[row][column] = "O";
            for (int i = 0; i <9; i++) {
                for (int j = 0; j < 9; j++) {
                    finisher_counter++;
                }
            }
            // show again the back ground!
            for (int i = 0; i <9; i++) {
                for (int j = 0; j < 9; j++) {
                    System.out.print(background[i][j] + " ");
                }
                System.out.println();
            }
            O_turn = false;
            I_turn = true;
        }
        else {
            System.out.println("it's not your turn");
        }

        if (I_turn = true) {
            System.out.println("please enter coordinate (first row and then column)");
            Scanner sc = new Scanner(System.in);
            int row = sc.nextInt();
            int column = sc.nextInt();
            for (int i = 0; i <9; i++) {
                for (int j = 0; j < 9; j++) {
                    background[row][column] = "I";
                    finisher_counter++;
                }
            }
            // show again the back ground!
            for (int i = 1; i <9; i++) {
                for (int j = 1; j < 9; j++) {
                    System.out.print(background[i][j] + " ");
                }
                System.out.println();
            }
            I_turn = false;
            O_turn = true;
        }
        else {
            System.out.println("it's not your turn");
        }
    }
}
