public class Back_ground {
    String[][] background = new String[9][9];
    int[] row = new int[9];
    int[] column =new  int[9];

    public void Set(){
        int[][] RowAndColumn = new int[9][9];

        for (int i = 0; i < 9; i++) {
            //RowAndColumn[i][0] = i;
            for (int j = 0; j < 9; j++) {
                RowAndColumn[i][j] = j;
            }
        }
        // print the table
        for (int i = 1; i < 9; i++) {
            System.out.print(RowAndColumn[i][0] + " ");
            System.out.println();
            for (int j = 0; j < 9; j++) {
                System.out.print(RowAndColumn[0][j] + " ");
            }
        }
        System.out.println();
    }

    public void Set_Row(){
        for (int i = 0; i < 9; i++) {
            row[i] = i;
        }
        // print the row
        for (int i = 1; i < 9; i++) {
            System.out.print(row[i] + " ");
        }
        System.out.println();
    }

    public void Set_Column(){
        for (int i = 0; i < 9; i++) {
            column[i] = i;
        }
        // print the column
        for (int i = 1; i < 9; i++) {
            System.out.print(column[i] + " ");
            System.out.println();
        }
    }

    public void Make_Background(){
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                background[i][j] = ".";
                background[4][4] = "I";
                background[5][4] = "O";
                background[4][5] = "O";
                background[5][5] = "I";
            }
        }
    }

    public void ShowArray(){
        for (int i = 1; i < 9; i++) {
            for (int j = 1; j < 9; j++) {
                System.out.print(background[i][j] + " ");
            }
            System.out.println();
        }
    }
}
