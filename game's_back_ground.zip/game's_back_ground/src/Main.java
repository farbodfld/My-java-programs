public class Main {
    public static void main(String[] args){
        Back_ground back_ground = new Back_ground();
       // back_ground.Set();
        /*back_ground.Set_Row();
        back_ground.Set_Column();*/
        back_ground.Make_Background();
        back_ground.ShowArray();
        Game_Setup gs = new Game_Setup();
        while (true) {
            if (gs.finisher_counter == 64) {
                break;
            } else {
                gs.whose_turn();
            }
        }
    }
}
