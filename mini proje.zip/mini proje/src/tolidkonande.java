import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class admin {
    static private String username;
    static private int password;
    static public String viecle;
    static private String tkuser;
    static private long tkpass;
    static private String bbuser;
    static private long bbpass;

    public admin() {
        Scanner input = new Scanner(System.in);
        System.out.println("set yor username");
        username = input.nextLine();
        System.out.println("set yor password");
        password = input.nextInt();
    }

    public static void settkuserandpass() {
        Scanner input = new Scanner(System.in);
        // System.out.println("set your barbar user and pass and viecle");
        System.out.println("set your tk username");
        tkuser = input.nextLine();
        System.out.println("set your tk password");
        tkpass = input.nextInt();
    }

    public static long gettkPassword() {
        return tkpass;
    }

    public static String gettkUsername() {
        return tkuser;
    }

    public static void setbbuserandpass() {
        Scanner input = new Scanner(System.in);
        System.out.println("set your barbar user");
        bbuser = input.nextLine();
        System.out.println("set your password");
        bbpass = input.nextInt();
        System.out.println("set your viecle");
        System.out.println("chose your viecle of motor or khodro or vanet");
        String viecle2 = input.next();
        if (viecle2.contains("motor")) {
            viecle = viecle2;
        }
        if (viecle2.contains("khodro")) {
            viecle = viecle2;
        }
        if (viecle2.contains("vanet")) {
            viecle = viecle2;
        }
    }

    public static long getbbPassword() {
        return bbpass;
    }

    public static String getbbUsername() {
        return bbuser;
    }

    public static int getPassword() {
        return password;
    }

    public void setPassword() {
        Scanner input = new Scanner(System.in);
        this.password = input.nextInt();//password;
    }

    public static String getUsername() {
        return username;
    }

    public void setUsername() {
        Scanner input = new Scanner(System.in);
        this.username = input.nextLine();//username;
    }

}

class tolidkonande {
    static public long sood = 0;
    static int counter = 0;
    static List<String> list = new ArrayList<>();
    static List<Long> passlist = new ArrayList<Long>();
    static tolidkonande[] lst = new tolidkonande[100];
    static String[] listeuserandpass = new String[100];
    static ArrayList<String> listetk = new ArrayList<>();
    static List<String> listekalaha = new ArrayList<String>();
    static List<String> listekalaha2 = new ArrayList<String>();
    static List<String> listekalaha3 = new ArrayList<String>();
    static public String user;
    static public long pass;

    public tolidkonande() {
        user = admin.gettkUsername();
        pass = admin.gettkPassword();
    }

    static int i = 0;

    public static void addtolidkonande() {
        lst[i] = new tolidkonande();
        i++;
    }

    public static void enteruserandpass() {
        Scanner input = new Scanner(System.in);
        System.out.println("enter yor username");
        String a = input.nextLine();
        System.out.println("enter yor password");
        int b = input.nextInt();
        if (a.contains(user) && b == pass) {
            System.out.println("wellcome");
        } else {
            System.out.println("please try again");
            enteruserandpass();
        }
        listetk.add(admin.gettkUsername());
        passlist.add(admin.gettkPassword());
    }

    public static List<String> ezafekardankala() {
        // System.out.println("please enter your item");
        Scanner input = new Scanner(System.in);
        // String item = input.nextLine();
        // byad ye if beznim ke chek kone aya item barabare kala hast ya na
        // be tedade kala ha if lazem darim
        System.out.println("please enter your count");
        int number = input.nextInt();
        // list = new String[number];
        System.out.println("please enter your item");
        String item = input.nextLine();
        if (item.contains("tanagholat") || item.contains("labaniat") || item.contains("mivevasabzijat")) {
            for (int i = 0; i < number; i++) {
                listekalaha.add(item);
                counter++;
            }
        } else if (item.contains("shalvar") || item.contains("pirahan") || item.contains("kafsh")) {
            for (int i = 0; i < number; i++) {
                listekalaha2.add(item);
                counter++;
            }
        } else if (item.contains("television") || item.contains("telefonehamrah") || item.contains("consolebazi")) {
            for (int i = 0; i < number; i++) {
                listekalaha3.add(item);
                counter++;
            }
        }
        System.out.println("your list will be:");
        return list;
    }

    public static List<String> hazfkardankala() {
        // System.out.println("please enter your item");
        Scanner input = new Scanner(System.in);
        // String item = input.nextLine();
        // byad ye if beznim ke chek kone aya item barabare kala hast ya na
        // be tedade kala ha if lazem darim
        System.out.println("please enter your count");
        int number = input.nextInt();
        //list = new String[number];
        System.out.println("please enter your item and item's number");
        String item = input.nextLine();
        int adad = input.nextInt();
        if (item.contains("tanagholat") || item.contains("labaniat") || item.contains("mivevasabzijat")) {
            for (int i = 0; i < number; i++) {
                listekalaha.remove(adad);
                counter--;
            }
        } else if (item.contains("shalvar") || item.contains("pirahan") || item.contains("kafsh")) {
            for (int i = 0; i < number; i++) {
                listekalaha2.remove(adad);
                counter--;
            }
        } else if (item.contains("television") || item.contains("telefonehamrah") || item.contains("consolebazi")) {
            for (int i = 0; i < number; i++) {
                listekalaha3.remove(adad);
                counter--;
            }
        }

        return list;
    }

    public static void discount() {
        Scanner input = new Scanner(System.in);
        System.out.println("please enter your item");
        String kala = input.nextLine();

        System.out.println("please enter your discount amount");
        int amount = input.nextInt();

        if (kala.contains("tanagholat") || kala.contains("labaniat") || kala.contains("mivevasabzijat")) {
            aghlamvaajnas.khoraki.price -= amount;
        } else if (kala.contains("shalvar") || kala.contains("pirahan") || kala.contains("kafsh")) {
            aghlamvaajnas.pooshak.price -= amount;
        } else if (kala.contains("television") || kala.contains("telefonehamrah") || kala.contains("consolebazi")) {
            aghlamvaajnas.lavazemelctrici.price -= amount;
        }
    }

    public static void tolidajnas() {
        System.out.println("please chose your product you want to make");
        Scanner input = new Scanner(System.in);
        String product = input.nextLine();
        if (product.contains("tanagholat") || product.contains("labaniat") || product.contains("mivevasabzijat")) {
            aghlamvaajnas.khoraki tanagholat = new aghlamvaajnas.khoraki();
            listekalaha.add(aghlamvaajnas.khoraki.getname());
        } else if (product.contains("shalvar") || product.contains("pirahan") || product.contains("kafsh")) {
            aghlamvaajnas.pooshak pooshak = new aghlamvaajnas.pooshak();
            listekalaha2.add(aghlamvaajnas.pooshak.getname());
        } else if (product.contains("television") || product.contains("telefonehamrah") || product.contains("consolebazi")) {
            aghlamvaajnas.lavazemelctrici lavazemelctrici = new aghlamvaajnas.lavazemelctrici();
            listekalaha3.add(aghlamvaajnas.lavazemelctrici.getname());
        }
    }

}

class barbar {
    static barbar[] bb = new barbar[100];
    static String username;
    static long password;
    public String noesefareshat;
    public String namesefareshat;
    static public long hajmesefareshat;
    static List<String> marsoolatedarhaleersal = new ArrayList<>();
    static List<String> sefareshatersalshode = new ArrayList<>();
    static List<String> userlistebb = new ArrayList<>();
    static List<Long> passlistebb = new ArrayList<>();
    static String motor;
    static String vanet;
    static String khodro;

    public barbar() {
        username = admin.getbbUsername();
        password = admin.getbbPassword();
    }

    static int j = 0;

    public static void addbarbar() {
        bb[j] = new barbar();
        j++;
    }

    public static void enteruserandpass() {
        Scanner input = new Scanner(System.in);
        //admin.setbbuserandpass();
        System.out.println("enter your username");
        String a = input.nextLine();
        System.out.println("enter your password");
        int b = input.nextInt();
        if (a.contains(username) && b == password) {
            System.out.println("wellcome");
        } else {
            System.out.println("please try again");
            enteruserandpass();
        }
        userlistebb.add(admin.getbbUsername());
        passlistebb.add(admin.getbbPassword());
    }

    public static void sefareshemoshtariha() {
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < moshtari.ajnasekharidarishode.size(); i++) {
            System.out.println(moshtari.ajnasekharidarishode.get(i));
        }
        if ((admin.viecle.contains("motor") && aghlamvaajnas.khoraki.Hajm == 0.5 ||
                aghlamvaajnas.pooshak.hajm == 0.5 ||
                aghlamvaajnas.lavazemelctrici.hajm == 0.5) ||
                (admin.viecle.contains("khodro") && aghlamvaajnas.pooshak.hajm == 2 ||
                        aghlamvaajnas.khoraki.Hajm == 2 ||
                        aghlamvaajnas.lavazemelctrici.hajm == 2) ||
                (admin.viecle.contains("vanet") && aghlamvaajnas.lavazemelctrici.hajm == 12 ||
                        aghlamvaajnas.khoraki.Hajm == 12 ||
                        aghlamvaajnas.pooshak.hajm == 12)) {
            System.out.println("how many ajnas do you want?");
            int n = input.nextInt();
            for (int i = 0; i < n; i++) {
                String selectitem = input.nextLine();
                marsoolatedarhaleersal.add(selectitem);
                moshtari.ajnasekharidarishode.remove(selectitem);
            }
        }
    }

    public static void marsoolatedarhaleersal() {
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < marsoolatedarhaleersal.size(); i++) {
            System.out.println(marsoolatedarhaleersal.get(i));
            System.out.println("chose item you want to send it");
            String item = input.nextLine();
            marsoolatedarhaleersal.remove(item);
            sefareshatersalshode.add(item);
        }
    }

    public static void Sefareshatersalshode() {
        for (int i = 0; i < sefareshatersalshode.size(); i++) {
            System.out.println(sefareshatersalshode.get(i));
        }
    }

    public static void taghyirvasilenaghlie() {
        Scanner input = new Scanner(System.in);
        System.out.println("which one of viecles do you want?");
        String choseviecle = input.next();
        if (choseviecle.contains("motor")) {
            admin.viecle = motor;
        } else if (choseviecle.contains("vanet")) {
            admin.viecle = vanet;
        } else if (choseviecle.contains("khodro")) {
            admin.viecle = khodro;
        }
    }
}

class aghlamvaajnas {
    public static class khoraki {
        Scanner input = new Scanner(System.in);
        static int price;
        static String Daste;
        static double Hajm;
        static String Sherkatsazande;
        static String Tarikhengheza;
        static String Shahresazande;
        static private String name;


        public static String setname() {
            Scanner input = new Scanner(System.in);
            System.out.println("set your product's name");
            name = input.nextLine();
            return name;
        }

        public static String getname() {
            return name;
        }

        public khoraki() {
            setname();
            System.out.println("set your price");
            price = input.nextInt();
            System.out.println("set your daste");
            Daste = input.next();//daste;
            System.out.println("set your hajm");
            Hajm = input.nextDouble();//hajm;
            System.out.println("set your sherkate sazande");
            Sherkatsazande = input.next();//sherkatsazande;
            System.out.println("set your tarikhe engheza");
            Tarikhengheza = input.nextLine();//tarikhengheza;
            System.out.println("do you want to set the city name?");
            String awnser = input.next();
            if (awnser.contains("yes")) {
                System.out.println("set your city name");
                Shahresazande = input.nextLine();
            }
        }
    }

    public static class pooshak {
        Scanner input = new Scanner(System.in);
        static int price;
        static String Daste;
        static String Daste2;
        static double hajm;
        static int Size;
        static char Size2;
        static String Jens;
        static String SherkateSazande;
        static String name;


        public static String setname() {
            Scanner input = new Scanner(System.in);
            System.out.println("set your name");
            name = input.nextLine();
            return name;
        }

        public static String getname() {
            return name;
        }

        public pooshak() {                    // bara kafsh
            setname();
            System.out.println("set your price");
            price = input.nextInt();
            System.out.println("set your daste");
            Daste = input.nextLine();//daste;
            System.out.println("women or men or kids");
            Daste2 = input.nextLine();//daste2;  // mard zan bache
            System.out.println("set your hajm");
            hajm = input.nextDouble();
            System.out.println("set your jens");
            Jens = input.nextLine();//jens;
            System.out.println("set your size");
            Size = input.nextInt();//size;
            System.out.println("set your sherkate sazande");
            SherkateSazande = input.nextLine();
            System.out.println("is your product shirts or pants?");
            String awnser2 = input.next();
            if (awnser2.contains("yes")) {
                System.out.println("L or M or S");
                Size2 = input.next().charAt(0);
            }
        }
    }

    public static class lavazemelctrici {
        Scanner input = new Scanner(System.in);
        static int price;
        static String Daste;
        static double hajm;
        static double SaleTolid;
        static double SizeSafhe;
        static String SherkateSazande;
        static String name;

        public static String setname() {
            Scanner input = new Scanner(System.in);
            System.out.println("set your name");
            String name = input.nextLine();
            return name;
        }

        public static String getname() {
            return name;
        }

        public lavazemelctrici() {
            setname();
            System.out.println("set your price");
            price = input.nextInt();
            System.out.println("set your daste");
            Daste = input.nextLine();//daste;
            System.out.println("set your hajm");
            hajm = input.nextDouble();
            System.out.println("set your sherkate sazande");
            SherkateSazande = input.nextLine();
            System.out.println("set your sale tolid");
            SaleTolid = input.nextDouble();//saletolid;
            System.out.println("set your size e safhe");
            SizeSafhe = input.nextDouble();//sizesafhe;
            System.out.println("is your product a counsole?");
            String awnser = input.next();
            if (awnser.contains("yes")) {
                System.out.println("how many fiture dose your console have?");
                int n = input.nextInt();
                String[] aghlamhamrah = new String[n];
                for (int i = 0; i < n; i++) {
                    String x = input.nextLine();
                    aghlamhamrah[i] = x;
                }
            }
        }
    }
}

class moshtari {
    static List<String> ajnasekharidarishode = new ArrayList<>();
    static List<String> safeersal = new ArrayList<>();
    static List<String> myList = new ArrayList<>();
    static public String username;
    static List</*Long*/String> myList2 = new ArrayList<>();
    static String[] listeuserandpass = new String[100];
    static long kharjemoshtari;
    static String password;

    public static void setmoshtari() {
        System.out.println("wellcome to Market");
        System.out.println("please set your username and password:");
        Scanner input = new Scanner(System.in);
        username = input.next();
        while (true) {
            if (myList.contains(username)) {
                System.out.println("please set another username");
                username = input.next();
            } else {
                myList.add(username);
                break;
            }
        }
        password = input.next();
        myList2.add(password);
        int i = 0;
        listeuserandpass[i] = username;
        i++;
        listeuserandpass[i] = password;
        i++;
    }

    public static void showlist() {
        for (String tolidkonande : tolidkonande.listetk) {
            System.out.print(admin.gettkUsername() + " ");
        }
        System.out.println();
        System.out.println("please enter your tolidkonande name");
        Scanner input = new Scanner(System.in);
        String name = input.next();
        if (tolidkonande.listetk.contains(name)) {
            for (String kala : tolidkonande.listekalaha) {
                System.out.println(aghlamvaajnas.khoraki.getname());
            }
            for (String kala : tolidkonande.listekalaha2) {
                System.out.println(aghlamvaajnas.pooshak.getname());
            }
            for (String kala : tolidkonande.listekalaha3) {
                System.out.println(aghlamvaajnas.lavazemelctrici.getname());
            }
            System.out.println("do you want any product?");
            String awmser = input.next();
            if (awmser.contains("yes")) {
                System.out.println("please enter product name");
                String productname = input.next();
                ajnasekharidarishode.add(productname);
                safeersal.add(productname);
                tolidkonande.sood++;
                kharjemoshtari++;
            }
        } else {
            System.out.println("your tolidkonande was not found");
        }
    }

    public static void showdastebandiajnas() {
        List<String> dastebandiajnas = new ArrayList<>();
        dastebandiajnas.add("mavade khoraki");
        dastebandiajnas.add("pooshak");
        dastebandiajnas.add("lavazeme electrici");
        for (int i = 0; i < dastebandiajnas.size(); i++) {
            System.out.print(dastebandiajnas.get(i) + " ");
        }
        System.out.println();
        System.out.println("chose your category");
        Scanner input = new Scanner(System.in);
        String category = input.nextLine();
        if (category.contains("mavade khoraki")) {
            for (String kala : tolidkonande.listekalaha) {
                System.out.println(aghlamvaajnas.khoraki.getname());
                System.out.println(aghlamvaajnas.khoraki.price);
                System.out.println(aghlamvaajnas.khoraki.Daste);
                System.out.println(aghlamvaajnas.khoraki.Hajm);
                System.out.println(aghlamvaajnas.khoraki.Tarikhengheza);
                System.out.println(aghlamvaajnas.khoraki.Sherkatsazande);
                System.out.println(aghlamvaajnas.khoraki.Shahresazande);
            }
        }
        if (category.contains("pooshak")) {
            for (String kala : tolidkonande.listekalaha2) {
                System.out.println(aghlamvaajnas.pooshak.getname());
                System.out.println(aghlamvaajnas.pooshak.price);
                System.out.println(aghlamvaajnas.pooshak.Daste);
                System.out.println(aghlamvaajnas.pooshak.Daste2);
                System.out.println(aghlamvaajnas.pooshak.hajm);
                System.out.println(aghlamvaajnas.pooshak.Size);
                System.out.println(aghlamvaajnas.pooshak.Size2);
                System.out.println(aghlamvaajnas.pooshak.Jens);
            }
        }
        if (category.contains("lavazeme electrici")) {
            for (String kala : tolidkonande.listekalaha3) {
                System.out.println(aghlamvaajnas.lavazemelctrici.getname());
                System.out.println(aghlamvaajnas.lavazemelctrici.price);
                System.out.println(aghlamvaajnas.lavazemelctrici.Daste);
                System.out.println(aghlamvaajnas.lavazemelctrici.SaleTolid);
                System.out.println(aghlamvaajnas.lavazemelctrici.hajm);
                System.out.println(aghlamvaajnas.lavazemelctrici.SizeSafhe);
                System.out.println(aghlamvaajnas.lavazemelctrici.SherkateSazande);
            }
        }
        System.out.println("do you want any product?");
        String awmser = input.nextLine();
        if (awmser.contains("yes")) {
            System.out.println("please enter product name");
            String productname = input.nextLine();
            ajnasekharidarishode.add(productname);
            safeersal.add(productname);
            tolidkonande.sood++;
            kharjemoshtari++;
        }
    }

    public static void showlistekharidarishode() {
        // String list[] = (String[]) ajnasekharidarishode.toArray();
        for (String s : ajnasekharidarishode) {
            System.out.print(s + " ");
        }
    }

    public static void showsafeersal() {
        for (String s : safeersal) {
            System.out.println(s);
        }
    }
}

class amarvaargham {
    public long showsood() {
        return tolidkonande.sood;
    }

    public long showkharjemoshtari() {
        return moshtari.kharjemoshtari;
    }

    public long showhajmejabejashode() {
        return barbar.hajmesefareshat;
    }

    public void kalahayekharidarishode() {
        for (int i = 0; i < moshtari.ajnasekharidarishode.size(); i++) {
            System.out.println(moshtari.ajnasekharidarishode.get(i));
        }
    }

    public void sefareshatejabejashode() {
        for (int i = 0; i < barbar.sefareshatersalshode.size(); i++) {
            System.out.println(barbar.sefareshatersalshode.get(i));
        }
    }

    public void kalahayefrookhteshode() {
        for (int i = 0; i < moshtari.ajnasekharidarishode.size(); i++) {
            System.out.println(moshtari.ajnasekharidarishode.get(i));
        }
    }
}

class test {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        while (true) {
            System.out.println("what do you want to do?");
            String state = input.nextLine();
            switch (state) {
                case "i am admin":
                    admin Admin = new admin();
                    break;
                case "i am tk":
                    System.out.println("sign in or sighn up!");
                    String aw = input.nextLine();
                    if (aw.contains("sighn in")) {
                        System.out.println("please enter your user and pass!");
                        String u = input.nextLine();
                        long p = input.nextLong();
                        while (true) {
                            if (tolidkonande.listetk.contains(u) && tolidkonande.passlist.contains(p)) {
                                System.out.println("wellcome");
                                break;
                            } else {
                                System.out.println("invalid username");
                                u = input.next();
                            }
                        }
                    } else if (aw.contains("sign up")) {
                        System.out.println("wait until admin gives you a user and pass");
                        System.out.println("please set your tolidkonande username and password:");
                        admin.settkuserandpass();
                        tolidkonande.addtolidkonande();
                        tolidkonande.enteruserandpass();
                    }
                    System.out.println("do you want to make new products?");
                    String awnser4 = input.next();
                    if (awnser4.contains("yes")) {
                        tolidkonande.tolidajnas();
                    }
                    System.out.println("do you want to add your products?");
                    String awnser = input.next();
                    if (awnser.contains("yes")) {
                        /*TK*/
                        tolidkonande.ezafekardankala();
                    }
                    System.out.println("do you want to remove your products?");
                    String awnser2 = input.next();
                    if (awnser2.contains("yes")) {
                        /*TK*/
                        tolidkonande.hazfkardankala();
                    }
                    System.out.println("do you want to discount your products?");
                    String awnser3 = input.next();
                    if (awnser3.contains("yes")) {
                        /*TK*/
                        tolidkonande.discount();
                    }
                    break;
                case "i am barbar":
                    System.out.println("sign in or sighn up!");
                    String aw2 = input.next();
                    if (aw2.contains("sighn in")) {
                        System.out.println("please enter your user and pass!");
                        String u = input.nextLine();
                        long p = input.nextLong();
                        while (true) {
                            if (barbar.userlistebb.contains(u) && barbar.passlistebb.contains(p)) {
                                System.out.println("wellcome");
                                break;
                            } else {
                                System.out.println("invalid username");
                            }
                        }
                    } else if (aw2.contains("sign up")) {
                        System.out.println("wait until admin gives you a user and pass");
                        System.out.println("please set your barbar username and password:");
                        admin.setbbuserandpass();
                        barbar.addbarbar();
                        barbar.enteruserandpass();
                    }
                    //BB.enteruserandpass();
                    System.out.println("which category do yo want?");
                    input.next();
                    String javab = input.nextLine();
                    if (javab.contains("sefareshat moshtariha")) {
                        barbar.sefareshemoshtariha();
                    } else if (javab.contains("marsoolate dar hale ersal")) {
                        barbar.marsoolatedarhaleersal();
                    } else if (javab.contains("sefareshat ersal shode")) {
                        barbar.Sefareshatersalshode();
                    } else if (javab.contains("taghyire vasileye naghlie")) {
                        barbar.taghyirvasilenaghlie();
                    }
                    break;
                case "i am moshtari":
                    System.out.println("sign in or sighn up!");
                    String aw3 = input.nextLine();
                    if (aw3.contains("sign in")) {
                        System.out.println("please enter your user and pass!");
                        String u = input.nextLine();
                        String p = input.next();
                        while (true) {
                            if (moshtari.listeuserandpass[0].equals(u) && moshtari.listeuserandpass[1].equals(p)) {
                                System.out.println("wellcome");
                                break;
                            } else {
                                System.out.println("invalid username");
                                u = input.next();
                                p = input.next();
                            }
                        }
                    } else if (aw3.contains("sign up")) {
                        moshtari.setmoshtari();
                    }
                    System.out.println("which one of the list do you want?");
                    input.nextLine();
                    String pasokh5 = input.nextLine();
                    if (pasokh5.contains("tolid konande ha")) {
                        moshtari.showlist();
                    } else if (pasokh5.contains("daste bandi ajnas")) {
                        moshtari.showdastebandiajnas();
                    } else if (pasokh5.contains("ajnase kharidari shode")) {
                        moshtari.showlistekharidarishode();
                    } else if (pasokh5.contains("ajnase dar dastoor e ersal")) {
                        moshtari.showsafeersal();
                    }
                    break;
                case "show amar va argham":
                    amarvaargham ava = new amarvaargham();
                    System.out.println("which one of list do you want?");
                    String pasokh2 = input.nextLine();
                    if (pasokh2.contains("mizan soode tolidkonande")) {
                        ava.showsood();
                    } else if (pasokh2.contains("mizan kharje moshtari")) {
                        ava.showkharjemoshtari();
                    } else if (pasokh2.contains("mizan hajme jabeja shode har barbar")) {
                        ava.showhajmejabejashode();
                    } else if (pasokh2.contains("liste kalahaye kharidari shode")) {
                        ava.kalahayekharidarishode();
                    } else if (pasokh2.contains("liste sefareshate jabeja shode")) {
                        ava.sefareshatejabejashode();
                    } else if (pasokh2.contains("liste kala haye frookhte shode")) {
                        ava.kalahayefrookhteshode();
                    }
                    break;
                case "exit":
                    return;
            }
        }

    }
}