public class Back_ground {
    /*String[][] background = new String[9][9];
    public Back_ground(){
        background[0][0] = " ";
        for (int i = 1; i < 9; i++) {
            background[0][i] = String.valueOf(i);
            background[i][0] = String.valueOf(i);
        }
        for (int i = 1; i < 9; i++) {
            for (int j = 1; j < 9; j++) {
                background[i][j] = ".";
            }
        }
        background[4][4] = "I";
        background[5][4] = "O";
        background[4][5] = "O";
        background[5][5] = "I";
    }

    public void ShowArray(){
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print(background[i][j] + " ");
            }
            System.out.println();
        }
    }*/
}
