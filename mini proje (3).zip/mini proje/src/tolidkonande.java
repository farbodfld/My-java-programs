import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class admin {
    static private String username;
    static private int password;
    static public String viecle;
    static private String tkuser;
    static private long tkpass;
    static private String bbuser;
    static private long bbpass;

    public admin() {
        Scanner input = new Scanner(System.in);
        System.out.println("set your username");
        username = input.nextLine();
        System.out.println("set your password");
        password = input.nextInt();
    }

    public static void settkuserandpass() {
        Scanner input = new Scanner(System.in);
        // System.out.println("set your barbar user and pass and viecle");
        System.out.println("set your tk username");
        tkuser = input.nextLine();
        System.out.println("set your tk password");
        tkpass = input.nextInt();
    }

    public static long gettkPassword() {
        return tkpass;
    }

    public static String gettkUsername() {
        return tkuser;
    }

    public static void setbbuserandpass() {
        Scanner input = new Scanner(System.in);
        System.out.println("set your barbar user");
        bbuser = input.nextLine();
        System.out.println("set your barbar password");
        bbpass = input.nextInt();
        System.out.println("set your barbar viecle");
        System.out.println("chose his viecle of motor or khodro or vanet");
        String viecle2 = input.next();
        if (viecle2.contains("motor")) {
            viecle = viecle2;
        }
        if (viecle2.contains("khodro")) {
            viecle = viecle2;
        }
        if (viecle2.contains("vanet")) {
            viecle = viecle2;
        }
    }

    public static long getbbPassword() {
        return bbpass;
    }

    public static String getbbUsername() {
        return bbuser;
    }

    public void login() {
        Scanner input = new Scanner(System.in);
        System.out.println("enter your username");
        String a = input.nextLine();
        System.out.println("enter your password");
        int b = input.nextInt();
        if (a.contains(username) && b == password) {
            System.out.println("wellcome");
        } else {
            System.out.println("please try again");
            login();
        }
        while (true) {
            System.out.println("for making producer acount enter: tk");
            System.out.println("for making postman acount enter: bb");
            System.out.println("or if you want to do somthing else enter: next");
            String jv = input.next();
            if (jv.contains("tk")) {
                tolidkonande tk = new tolidkonande();
                admin.settkuserandpass();
                tk.addtolidkonande();
            } else if (jv.contains("bb")) {
                barbar bb = new barbar();
                admin.setbbuserandpass();
                bb.addbarbar();
            } else if (jv.contains("next")) {
                System.out.println("for see sood of producer enter: show sood");
                System.out.println("for see producer's money spent enter: show kharje moshtari");
                System.out.println("for see hajme jabeja shode of producer enter: show hajme jabeja shode");
                System.out.println("or if you want to log out enter : log out");
                amarvaargham ava = new amarvaargham();
                input.nextLine();
                String jv2 = input.nextLine();
                if (jv2.contains("show sood")) {
                    System.out.println("your producer's income is : " + tolidkonande.getSood());
                } else if (jv2.contains("show kharje moshtari")) {
                    System.out.println("your producer's income is : " + ava.showkharjemoshtari());
                } else if (jv2.contains("show hajme jabeja shode")) {
                    ava.showhajmejabejashode();
                    System.out.println("your producer's income is : " + ava.showhajmejabejashode());
                } else if (jv2.contains("log out")) {
                    return;
                }
            }
        }
    }

    public static int getPassword() {
        return password;
    }

    public void setPassword() {
        Scanner input = new Scanner(System.in);
        this.password = input.nextInt();//password;
    }

    public static String getUsername() {
        return username;
    }

    public void setUsername() {
        Scanner input = new Scanner(System.in);
        this.username = input.nextLine();//username;
    }

}

class tolidkonande {
    static public int sood = 0;
    static int counter = 0;
    static List<String> list = new ArrayList<>();
    static List<Long> passlist = new ArrayList<Long>();
    static tolidkonande[] lst = new tolidkonande[100];
    static String[] listeuserandpass = new String[100];
    static ArrayList<String> listetk = new ArrayList<>();
    static List<String> listekalaha = new ArrayList<String>();
    static List<String> listekalaha2 = new ArrayList<String>();
    static List<String> listekalaha3 = new ArrayList<String>();
    static public String user;
    static public long pass;

    public tolidkonande() {
        user = admin.gettkUsername();
        pass = admin.gettkPassword();
    }

    static int i = 0;

    public void addtolidkonande() {
        lst[i] = new tolidkonande();
        i++;
    }

    public static void enteruserandpass() {
        Scanner input = new Scanner(System.in);
        System.out.println("enter your username");
        String a = input.nextLine();
        System.out.println("enter your password");
        int b = input.nextInt();
        if (a.contains(user) && b == pass) {
            System.out.println("wellcome");
        } else {
            System.out.println("invalid username or password");
            System.out.println("please try again");
            enteruserandpass();
        }
        listetk.add(admin.gettkUsername());
        passlist.add(admin.gettkPassword());
    }

    public static void ezafekardankala() {
        // System.out.println("please enter your item");
        Scanner input = new Scanner(System.in);
        // String item = input.nextLine();
        // byad ye if beznim ke chek kone aya item barabare kala hast ya na
        // be tedade kala ha if lazem darim
        System.out.println("please enter your count");
        int number = input.nextInt();
        // list = new String[number];
        System.out.println("please enter your item");
        input.nextLine();
        String item = input.nextLine();
        if (item.contains("tanagholat") || item.contains("labaniat") || item.contains("mivevasabzijat")) {
            for (int i = 0; i < number; i++) {
                listekalaha.add(item);
                counter++;
            }
            System.out.println("your new list will be:");
            for (int j = 0; j < listekalaha.size(); j++) {
                System.out.println(listekalaha.get(i) + " ");
            }
        } else if (item.contains("shalvar") || item.contains("pirahan") || item.contains("kafsh")) {
            for (int i = 0; i < number; i++) {
                listekalaha2.add(item);
                counter++;
            }
            System.out.println("your new list will be:");
            for (int j = 0; j < listekalaha2.size(); j++) {
                System.out.println(listekalaha2.get(i) + " ");
            }
        } else if (item.contains("television") || item.contains("telefonehamrah") || item.contains("consolebazi")) {
            for (int i = 0; i < number; i++) {
                listekalaha3.add(item);
                counter++;
            }
            System.out.println("your new list will be:");
            for (int j = 0; j < listekalaha3.size(); j++) {
                System.out.println(listekalaha3.get(i) + " ");
            }
        }
    }

    public static void hazfkardankala() {
        // System.out.println("please enter your item");
        Scanner input = new Scanner(System.in);
        // String item = input.nextLine();
        // byad ye if beznim ke chek kone aya item barabare kala hast ya na
        // be tedade kala ha if lazem darim
        System.out.println("please enter your count");
        int number = input.nextInt();
        //list = new String[number];
        System.out.println("please enter your item and item's number");
        String item = input.nextLine();
        int adad = input.nextInt();
        if (item.contains("tanagholat") || item.contains("labaniat") || item.contains("mivevasabzijat")) {
            for (int i = 0; i < number; i++) {
                listekalaha.remove(adad);
                counter--;
            }
            System.out.println("your new list will be:");
            for (int j = 0; j < listekalaha.size(); j++) {
                System.out.println(listekalaha.get(i) + " ");
            }
        } else if (item.contains("shalvar") || item.contains("pirahan") || item.contains("kafsh")) {
            for (int i = 0; i < number; i++) {
                listekalaha2.remove(adad);
                counter--;
            }
            System.out.println("your new list will be:");
            for (int j = 0; j < listekalaha2.size(); j++) {
                System.out.println(listekalaha2.get(i) + " ");
            }
        } else if (item.contains("television") || item.contains("telefonehamrah") || item.contains("consolebazi")) {
            for (int i = 0; i < number; i++) {
                listekalaha3.remove(adad);
                counter--;
            }
            System.out.println("your new list will be:");
            for (int j = 0; j < listekalaha3.size(); j++) {
                System.out.println(listekalaha3.get(i) + " ");
            }
        }
    }

    public static void discount() {
        Scanner input = new Scanner(System.in);
        System.out.println("please enter your item");
        String kala = input.nextLine();

        System.out.println("please enter your discount amount");
        int amount = input.nextInt();
       /* if (kala.contains(goods.name)) {
            goods.price = goods.price * amount / 100;
        } else {
            System.out.println("invalid item");
        }  */

        if (kala.contains("tanagholat") || kala.contains("labaniat") || kala.contains("mivevasabzijat")) {
            /*aghlamvaajnas.*/
            khoraki.price -= amount;
        } else if (kala.contains("shalvar") || kala.contains("pirahan") || kala.contains("kafsh")) {
            /*aghlamvaajnas.*/
            pooshak.price -= amount;
        } else if (kala.contains("television") || kala.contains("telefonehamrah") || kala.contains("consolebazi")) {
            /*aghlamvaajnas.*/
            lavazemelctrici.price -= amount;
        }
    }

    public static void tolidajnas() {
        System.out.println("please enter your product's category you want to make");
        Scanner input = new Scanner(System.in);
        String product = input.nextLine();
        if (product.contains("tanagholat") || product.contains("labaniat") || product.contains("mivevasabzijat")) {
            /*aghlamvaajnas.*/
            khoraki tanagholat = new /*aghlamvaajnas.*/khoraki();
            listekalaha.add(/*aghlamvaajnas.*/khoraki.getname());
        } else if (product.contains("shalvar") || product.contains("pirahan") || product.contains("kafsh")) {
            /*aghlamvaajnas.*/
            pooshak pooshak = new /*aghlamvaajnas.*/pooshak();
            listekalaha2.add(/*aghlamvaajnas.*/pooshak.getname());
        } else if (product.contains("television") || product.contains("telefonehamrah") || product.contains("consolebazi")) {
            /* aghlamvaajnas.*/
            lavazemelctrici lavazemelctrici = new /*aghlamvaajnas.*/lavazemelctrici();
            listekalaha3.add(/*aghlamvaajnas.*/lavazemelctrici.getname());
        }
    }

    public static int getSood() {
        return sood;
    }

    /**************************/

    public static void makenewproduct() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter name of product");
        String pr_name = input.next();
        System.out.println("Enter size of your product");
        double size = input.nextDouble();
        System.out.println("Enter price of product");
        double price = input.nextDouble();
        String Manufacturer = user;

        // goods x=new goods(price,size,pr_name,Manufacturer);
        System.out.println("Enter type of this product :\n if is Electronis Enter : elec \n if is food Enter : food \nif is Apparel Enter :apr");
        String naghi = input.next();
        if (naghi.equals("elec")) {
            System.out.println("Enter years of make");
            int a = input.nextInt();
            Electeronics e = new Electeronics(price, size, pr_name, Manufacturer, a);
            listekalaha3.add(pr_name);
            System.out.println("Finished");
        } else if (naghi.equals("food")) {

            System.out.println("Enter Expired time");
            int expired = input.nextInt();
            foods f = new foods(price, size, pr_name, Manufacturer, expired);
            listekalaha.add(pr_name);

            System.out.println("Enter type of your foods : ");
            System.out.println("Enter dairy");
            System.out.println("Enter junk");
            System.out.println("Enter veg");

            String typeoffood = input.next();
            if (typeoffood.equals("junk")) {
                junkfoodordairy j = new junkfoodordairy(price, size, pr_name, Manufacturer, expired);
                listekalaha.add(pr_name);
                System.out.println("Finished");
            } else if (typeoffood.equals("veg")) {

                System.out.println("Enter city name that produced :(string)");
                String n = input.next();
                vegtebels v = new vegtebels(price, size, pr_name, Manufacturer, expired, n);
                listekalaha.add(pr_name);
                System.out.println("Finished");
            } else if (typeoffood.equals("dairy")) {
                junkfoodordairy da = new junkfoodordairy(price, size, pr_name, Manufacturer, expired);
                listekalaha.add(pr_name);
                System.out.println("Finished");
            }
        } else if (naghi.equals("apr")) {

            System.out.println("Enter Gender name");
            String gender = input.next();
            Apparel ap = new Apparel(price, size, pr_name, Manufacturer, gender);
            listekalaha3.add(pr_name);

            System.out.println("Enter type of Apparel\nEnter shirt\nEnter shoe\n Enter pants");
            String typeofApparel = input.next();

            if (typeofApparel.equals("shirt")) {

                System.out.println("Enter size of body between : S , M , L");
                String sizes = input.next();
                shirtorpants sh = new shirtorpants(price, size, pr_name, Manufacturer, gender, sizes);
                listekalaha3.add(pr_name);
                System.out.println("Finished");
            }
            if (typeofApparel.equals("shoe")) {

                System.out.println("Enter size of shoe");
                int sizeshoe = input.nextInt();
                shoe shoe1 = new shoe(price, size, pr_name, Manufacturer, gender, sizeshoe);
                listekalaha3.add(pr_name);
                System.out.println("Finished");
            }
            if (typeofApparel.equals("pants")) {

                System.out.println("Enter size body between : S , M , L");
                String sizes = input.next();
                shirtorpants pa = new shirtorpants(price, size, pr_name, Manufacturer, gender, sizes);
                listekalaha3.add(pr_name);
                System.out.println("Finished");
            }
        } else {
            System.out.println("invalid category ");
        }
    }

    /**************************/

}

class barbar {
    static barbar[] bb = new barbar[100];
    static String username;
    static long password;
    public String noesefareshat;
    public String namesefareshat;
    static public long hajmesefareshat;
    static List<String> marsoolatedarhaleersal = new ArrayList<>();
    static List<String> sefareshatersalshode = new ArrayList<>();
    static List<String> userlistebb = new ArrayList<>();
    static List<Long> passlistebb = new ArrayList<>();
    static String motor;
    static String vanet;
    static String khodro;

    public barbar() {
        username = admin.getbbUsername();
        password = admin.getbbPassword();
    }

    static int j = 0;

    public void addbarbar() {
        bb[j] = new barbar();
        j++;
    }

    public static void enteruserandpass() {
        Scanner input = new Scanner(System.in);
        //admin.setbbuserandpass();
        System.out.println("enter your username");
        String a = input.nextLine();
        System.out.println("enter your password");
        int b = input.nextInt();
        if (a.contains(username) && b == password) {
            System.out.println("wellcome");
        } else {
            System.out.println("invalid username or password!");
            System.out.println("please try again");
            enteruserandpass();
        }
        userlistebb.add(admin.getbbUsername());
        passlistebb.add(admin.getbbPassword());
    }

    public static void sefareshemoshtariha() {
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < moshtari.ajnasekharidarishode.size(); i++) {
            System.out.println(moshtari.ajnasekharidarishode.get(i));
        }
        if ((admin.viecle.contains("motor") && /*aghlamvaajnas.*/khoraki.Hajm == 0.5 ||
                /*aghlamvaajnas.*/pooshak.hajm == 0.5 ||
                /*aghlamvaajnas.*/lavazemelctrici.Hajm == 0.5) ||
                (admin.viecle.contains("khodro") && /*aghlamvaajnas.*/pooshak.hajm == 2 ||
                        /*aghlamvaajnas.*/khoraki.Hajm == 2 ||
                        /* aghlamvaajnas.*/lavazemelctrici.hajm == 2) ||
                (admin.viecle.contains("vanet") && /*aghlamvaajnas.*/lavazemelctrici.Hajm == 12 ||
                        /*aghlamvaajnas.*/khoraki.Hajm == 12 ||
                        /*aghlamvaajnas.*/pooshak.hajm == 12)) {
            System.out.println("how many ajnas do you want?");
            int n = input.nextInt();
            for (int i = 0; i < n; i++) {
                String selectitem = input.nextLine();
                marsoolatedarhaleersal.add(selectitem);
                moshtari.ajnasekharidarishode.remove(selectitem);
            }
        }
    }

    public static void marsoolatedarhaleersal() {
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < marsoolatedarhaleersal.size(); i++) {
            System.out.println(marsoolatedarhaleersal.get(i));
            System.out.println("chose item you want to send it");
            String item = input.nextLine();
            marsoolatedarhaleersal.remove(item);
            sefareshatersalshode.add(item);
        }
    }

    public static void Sefareshatersalshode() {
        for (int i = 0; i < sefareshatersalshode.size(); i++) {
            System.out.println(sefareshatersalshode.get(i));
        }
    }

    public static void taghyirvasilenaghlie() {
        Scanner input = new Scanner(System.in);
        System.out.println("which one of viecles do you want?");
        String choseviecle = input.next();
        if (choseviecle.contains("motor")) {
            admin.viecle = motor;
        } else if (choseviecle.contains("vanet")) {
            admin.viecle = vanet;
        } else if (choseviecle.contains("khodro")) {
            admin.viecle = khodro;
        }
    }
}

class aghlamvaajnas {
    static String Daste;
    static double Hajm;
    static double hajm;
    static int price;
    static String Shahresazande;
    static String SherkateSazande;
}

class khoraki extends aghlamvaajnas {
    Scanner input = new Scanner(System.in);


    static String Sherkatsazande;
    static int Tarikhengheza;

    static private String name;


    public static String setname() {
        Scanner input = new Scanner(System.in);
        System.out.println("set your product's name");
        name = input.nextLine();
        return name;
    }

    public static String getname() {
        return name;
    }

    public khoraki() {
        setname();
        System.out.println("set your price");
        price = input.nextInt();
        System.out.println("set your daste");
        Daste = input.next();//daste;
        System.out.println("set your hajm");
        Hajm = input.nextDouble();//hajm;
        System.out.println("set your sherkate sazande");
        Sherkatsazande = input.next();//sherkatsazande;
        System.out.println("set your tarikhe engheza");
        Tarikhengheza = input.nextInt();//tarikhengheza;
        System.out.println("do you want to set the city name?");
        String awnser = input.next();
        if (awnser.contains("yes")) {
            System.out.println("set your city name");
            Shahresazande = input.nextLine();
        }
    }
}

class pooshak extends aghlamvaajnas {
    Scanner input = new Scanner(System.in);
    //static int price;
    // static String Daste;
    static String Daste2;

    static int Size;
    static char Size2;
    static String Jens;
    // static String SherkateSazande;
    static String name;


    public static String setname() {
        Scanner input = new Scanner(System.in);
        System.out.println("set your name");
        name = input.nextLine();
        return name;
    }

    public static String getname() {
        return name;
    }

    public pooshak() {                    // bara kafsh
        setname();
        System.out.println("set your price");
        price = input.nextInt();
        System.out.println("set your daste");
        Daste = input.nextLine();//daste;
        System.out.println("women or men or kids");
        Daste2 = input.nextLine();//daste2;  // mard zan bache
        System.out.println("set your hajm");
        hajm = input.nextDouble();
        System.out.println("set your jens");
        Jens = input.nextLine();//jens;
        System.out.println("set your size");
        Size = input.nextInt();//size;
        System.out.println("set your sherkate sazande");
        SherkateSazande = input.nextLine();
        System.out.println("is your product shirts or pants?");
        String awnser2 = input.next();
        if (awnser2.contains("yes")) {
            System.out.println("L or M or S");
            Size2 = input.next().charAt(0);
        }
    }
}

class lavazemelctrici extends aghlamvaajnas {
    Scanner input = new Scanner(System.in);
    //static int price;
    // static String Daste;
    //static double hajm;
    static double SaleTolid;
    static double SizeSafhe;
    // static String SherkateSazande;
    static String name;

    public static String setname() {
        Scanner input = new Scanner(System.in);
        System.out.println("set your name");
        String name = input.nextLine();
        return name;
    }

    public static String getname() {
        return name;
    }

    public lavazemelctrici() {
        setname();
        System.out.println("set your price");
        price = input.nextInt();
        System.out.println("set your daste");
        Daste = input.nextLine();//daste;
        System.out.println("set your hajm");
        hajm = input.nextDouble();
        System.out.println("set your sherkate sazande");
        SherkateSazande = input.nextLine();
        System.out.println("set your sale tolid");
        SaleTolid = input.nextDouble();//saletolid;
        System.out.println("set your size e safhe");
        SizeSafhe = input.nextDouble();//sizesafhe;
        System.out.println("is your product a counsole?");
        String awnser = input.next();
        if (awnser.contains("yes")) {
            System.out.println("how many fiture dose your console have?");
            int n = input.nextInt();
            String[] aghlamhamrah = new String[n];
            for (int i = 0; i < n; i++) {
                String x = input.nextLine();
                aghlamhamrah[i] = x;
            }
        }
    }
}

/*******************************/
class goods {
    static double price;
    double size;
    String sherkatesazande;
    static String name;

    public goods(double p, double s, String n, String sh) {
        price = p;
        size = s;
        name = n;
        sherkatesazande = sh;
    }
}

class foods extends goods {

    int Expiredtime = 0;

    foods(double p, double s, String n, String sh, int ex) {
        super(p, s, n, sh);
        Expiredtime = ex;
    }
}

class vegtebels extends foods {
    String cityname;

    vegtebels(double p, double s, String n, String sh, int ex, String ci_name) {
        super(p, s, n, sh, ex);
        cityname = ci_name;
    }

}

class junkfoodordairy extends foods {
    junkfoodordairy(double p, double s, String n, String sh, int ex) {
        super(p, s, n, sh, ex);

    }

}

class Electeronics extends goods {
    int year_of_construction;

    Electeronics(double p, double s, String n, String sh, int construct) {
        super(p, s, n, sh);
        year_of_construction = construct;
    }
}

class Console extends Electeronics {
    String others;

    Console(double p, double s, String n, String sh, int construct, String others) {
        super(p, s, n, sh, construct);
        this.others = others;
    }

}

class TVorPhone extends Electeronics {
    int monitorsize;

    TVorPhone(double p, double s, String n, String sh, int construct, int Monitor) {
        super(p, s, n, sh, construct);
        monitorsize = Monitor;
    }
}

class Apparel extends goods {
    String Gender;

    Apparel(double p, double s, String n, String sh, String gender) {
        super(p, s, n, sh);
        Gender = gender;
    }
}

class shoe extends Apparel {
    int sizenum;

    shoe(double p, double s, String n, String sh, String gender, int sizenum) {
        super(p, s, n, sh, gender);
        this.sizenum = sizenum;
    }
}

class shirtorpants extends Apparel {
    String sizebody;

    shirtorpants(double p, double s, String n, String sh, String gender, String sizebody) {
        super(p, s, n, sh, gender);
        this.sizebody = sizebody;
    }
}

/**********************************/

class moshtari {
    static List<String> ajnasekharidarishode = new ArrayList<>();
    static List<String> safeersal = new ArrayList<>();
    static List<String> myList = new ArrayList<>();
    static public String username;
    static List</*Long*/String> myList2 = new ArrayList<>();
    static String[] listeuserandpass = new String[100];
    static long kharjemoshtari;
    static String password;

    public static void setmoshtari() {
        System.out.println("wellcome to Market");
        System.out.println("please set your username and password:");
        Scanner input = new Scanner(System.in);
        username = input.next();
        while (true) {
            if (myList.contains(username)) {
                System.out.println("please set another username");
                username = input.next();
            } else {
                myList.add(username);
                break;
            }
        }
        password = input.next();
        if (password.length() < 6) {
            System.out.println("your password's less than 6 charecter!");
            password = input.next();
        } else {
            myList2.add(password);
        }
        int i = 0;
        listeuserandpass[i] = username;
        i++;
        listeuserandpass[i] = password;
        i++;
    }

    public static void showlist() {
        for (String tolidkonande : tolidkonande.listetk) {
            System.out.print(admin.gettkUsername() + " ");
        }
        System.out.println();
        System.out.println("please enter your tolidkonande name");
        Scanner input = new Scanner(System.in);
        String name = input.next();
        if (tolidkonande.listetk.contains(name)) {
            for (String kala : tolidkonande.listekalaha) {
                System.out.println(khoraki.getname());
            }
            for (String kala : tolidkonande.listekalaha2) {
                System.out.println(/*aghlamvaajnas.*/pooshak.getname());
            }
            for (String kala : tolidkonande.listekalaha3) {
                System.out.println(/*aghlamvaajnas.*/lavazemelctrici.getname());
            }
            System.out.println("do you want any product?");
            String awmser = input.next();
            if (awmser.contains("yes")) {
                System.out.println("please enter product name");
                String productname = input.next();
                ajnasekharidarishode.add(productname);
                safeersal.add(productname);
                tolidkonande.sood += aghlamvaajnas.price;
                kharjemoshtari += aghlamvaajnas.price;
                System.out.println("finished");
            }
        } else {
            System.out.println("your tolidkonande was not found");
        }
    }

    public static void showdastebandiajnas() {
        List<String> dastebandiajnas = new ArrayList<>();
        dastebandiajnas.add("mavade khoraki");
        dastebandiajnas.add("pooshak");
        dastebandiajnas.add("lavazeme electrici");
        for (int i = 0; i < dastebandiajnas.size(); i++) {
            System.out.print(dastebandiajnas.get(i) + " ");
        }
        System.out.println();
        System.out.println("chose your category");
        Scanner input = new Scanner(System.in);
        String category = input.nextLine();
        if (category.contains("mavade khoraki")) {
            for (String kala : tolidkonande.listekalaha) {
                System.out.println(/*aghlamvaajnas.*/khoraki.getname());
                System.out.println(/*aghlamvaajnas.*/khoraki.price);
                System.out.println(/*aghlamvaajnas.*/khoraki.Daste);
                System.out.println(/*aghlamvaajnas.*/khoraki.Hajm);
                System.out.println(/*aghlamvaajnas.*/khoraki.Tarikhengheza);
                System.out.println(/*aghlamvaajnas.*/khoraki.Sherkatsazande);
                System.out.println(/*aghlamvaajnas.*/khoraki.Shahresazande);
            }
        }
        if (category.contains("pooshak")) {
            for (String kala : tolidkonande.listekalaha2) {
                System.out.println(/*aghlamvaajnas.*/pooshak.getname());
                System.out.println(/*aghlamvaajnas.*/pooshak.price);
                System.out.println(/*aghlamvaajnas.*/pooshak.Daste);
                System.out.println(/*aghlamvaajnas.*/pooshak.Daste2);
                System.out.println(/*aghlamvaajnas.*/pooshak.hajm);
                System.out.println(/*aghlamvaajnas.*/pooshak.Size);
                System.out.println(/*aghlamvaajnas.*/pooshak.Size2);
                System.out.println(/*aghlamvaajnas.*/pooshak.Jens);
            }
        }
        if (category.contains("lavazeme electrici")) {
            for (String kala : tolidkonande.listekalaha3) {
                System.out.println(/*aghlamvaajnas.*/lavazemelctrici.getname());
                System.out.println(/*aghlamvaajnas.*/lavazemelctrici.price);
                System.out.println(/*aghlamvaajnas.*/lavazemelctrici.Daste);
                System.out.println(/*aghlamvaajnas.*/lavazemelctrici.SaleTolid);
                System.out.println(/*aghlamvaajnas.*/lavazemelctrici.Hajm);
                System.out.println(/*aghlamvaajnas.*/lavazemelctrici.SizeSafhe);
                System.out.println(/*aghlamvaajnas.*/lavazemelctrici.SherkateSazande);
            }
        }
        System.out.println("do you want any product?");
        String awmser = input.nextLine();
        if (awmser.contains("yes")) {
            System.out.println("please enter product name");
            String productname = input.nextLine();
            ajnasekharidarishode.add(productname);
            safeersal.add(productname);
            tolidkonande.sood++;
            kharjemoshtari++;
        }
    }

    public static void showlistekharidarishode() {
        // String list[] = (String[]) ajnasekharidarishode.toArray();
        for (String s : ajnasekharidarishode) {
            System.out.print(s + " ");
        }
    }

    public static void showsafeersal() {
        for (String s : safeersal) {
            System.out.println(s);
        }
    }
}

class amarvaargham {
    public void showsood() {
        tolidkonande.getSood();
    }

    public long showkharjemoshtari() {
        return moshtari.kharjemoshtari;
    }

    public long showhajmejabejashode() {
        return barbar.hajmesefareshat;
    }

    public void kalahayekharidarishode() {
        for (int i = 0; i < moshtari.ajnasekharidarishode.size(); i++) {
            System.out.println(moshtari.ajnasekharidarishode.get(i));
        }
    }

    public void sefareshatejabejashode() {
        for (int i = 0; i < barbar.sefareshatersalshode.size(); i++) {
            System.out.println(barbar.sefareshatersalshode.get(i));
        }
    }

    public void kalahayefrookhteshode() {
        for (int i = 0; i < moshtari.ajnasekharidarishode.size(); i++) {
            System.out.println(moshtari.ajnasekharidarishode.get(i));
        }
    }
}

class test {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("first of all make admin account!");
        admin Admin = new admin();
        System.out.println("do you want to login?");
        String a = input.next();
        if (a.contains("yes")) {
            Admin.login();
        }
        while (true) {
            System.out.println("Wellcome! please tell us who are you?");
            System.out.println("if you are admin and want to login to your account please type: i am admin");
            System.out.println("if you are producer please type: i am tk");
            System.out.println("if you are postman please type: i am barbar");
            System.out.println("if you are client please type: i am moshtari");
            System.out.println("if you want to exit the Market enter : exit");
            input.nextLine();
            String state = input.nextLine();
            switch (state) {
                case "i am admin":
                    Admin.login();
                    break;
                case "i am tk":
                    System.out.println("sign in or sign up!");
                    String aw = input.nextLine();
                    if (aw.contains("sign in")) {
                        tolidkonande.enteruserandpass();
                    } else if (aw.contains("sign up")) {
                        System.out.println("wait until admin gives you a user and pass");
                        Admin.login();
                        break;
                    }
                    System.out.println("do you want to make new products?");
                    String awnser4 = input.next();
                    if (awnser4.contains("yes")) {
                        tolidkonande.tolidajnas();
                    }
                    System.out.println("do you want to add your products?");
                    String awnser = input.next();
                    if (awnser.contains("yes")) {
                        /*TK*/
                        tolidkonande.ezafekardankala();
                    }
                    System.out.println("do you want to remove your products?");
                    String awnser2 = input.next();
                    if (awnser2.contains("yes")) {
                        /*TK*/
                        tolidkonande.hazfkardankala();
                    }
                    System.out.println("do you want to discount your products?");
                    String awnser3 = input.next();
                    if (awnser3.contains("yes")) {
                        /*TK*/
                        tolidkonande.discount();
                    }
                    System.out.println("do you want to see your status?");
                    String awnser6 = input.next();
                    if (awnser6.contains("yes")) {
                        /*TK*/
                        System.out.println("your income is : " + tolidkonande.getSood());
                        System.out.println("your product which is sold is : ");
                        for (int i = 0; i < moshtari.ajnasekharidarishode.size(); i++) {
                            System.out.println(moshtari.ajnasekharidarishode.get(i));
                        }
                    }
                    break;
                case "i am barbar":
                    System.out.println("sign in or sign up!");
                    String aw2 = input.next();
                    if (aw2.contains("sign in")) {
                        barbar.enteruserandpass();
                    } else if (aw2.contains("sign up")) {
                        System.out.println("wait until admin gives you a user and pass");
                        Admin.login();
                        break;
                    }
                    System.out.println("which category do yo want? \n1)sefareshat moshtariha \n2)marsoolate dar hale ersal \n3)sefareshat ersal shode \n4)taghyire vasileye naghlie");
                    // input.next();
                    int javab = input.nextInt();
                    if (javab == 1) {
                        barbar.sefareshemoshtariha();
                    } else if (javab == 2) {
                        barbar.marsoolatedarhaleersal();
                    } else if (javab == 3) {
                        barbar.Sefareshatersalshode();
                    } else if (javab == 4) {
                        barbar.taghyirvasilenaghlie();
                    }
                    System.out.println("do you want to see your status?");
                    String javab2 = input.next();
                    if (javab2.equals("yes")) {
                        System.out.println("your hajme jabe ja shode is :" + barbar.hajmesefareshat);
                        System.out.println("your liste jabe ja shode is :");
                        for (int i = 0; i < barbar.sefareshatersalshode.size(); i++) {
                            System.out.println(barbar.sefareshatersalshode.get(i));
                        }
                    }
                    break;
                case "i am moshtari":
                    System.out.println("sign in or sign up!");
                    String aw3 = input.nextLine();
                    if (aw3.contains("sign in")) {
                        System.out.println("please enter your user and pass!");
                        String u = input.nextLine();
                        String p = input.next();
                        while (true) {
                            if (moshtari.listeuserandpass[0].equals(u) && moshtari.listeuserandpass[1].equals(p)) {
                                System.out.println("wellcome");
                                break;
                            } else {
                                System.out.println("invalid username");
                                u = input.next();
                                p = input.next();
                            }
                        }
                    } else if (aw3.contains("sign up")) {
                        moshtari.setmoshtari();
                    }
                    System.out.println("which one of the list do you want? \n1)tolid konande ha \n2)daste bandi ajnas \n3)ajnase kharidari shode \n4)ajnase dar dastoor e ersal");

                    int pasokh5 = input.nextInt();
                    if (pasokh5 == 1) {
                        moshtari.showlist();
                    } else if (pasokh5 == 2) {
                        moshtari.showdastebandiajnas();
                    } else if (pasokh5 == 3) {
                        moshtari.showlistekharidarishode();
                    } else if (pasokh5 == 4) {
                        moshtari.showsafeersal();
                    }
                    System.out.println("do you want to see your status?");
                    String javab3 = input.next();
                    if (javab3.equals("yes")) {
                        System.out.println("your payment is :" + moshtari.kharjemoshtari);
                        System.out.println("your cart is :");
                        for (int i = 0; i < moshtari.ajnasekharidarishode.size(); i++) {
                            System.out.println(moshtari.ajnasekharidarishode.get(i));
                        }
                    }
                    break;
                case "exit":
                    return;
            }
        }

    }
}